import React, {Component} from 'react';
import {render} from 'react-dom';
import CapitalizedText from "./letter.js";
import './index.css';

class PetList extends Component {
    
      state = {
        petlist: [],
        image: [],
        urllist: [],
        selectedInputName: " ",
        showtitle: false
      }

      handleChange = (event) => {
        this.setState({showtitle: true});

        this.setState({
          selectedInputName: event.target.value
        });
      }  

      makeTextInput = () => (
           <p>{this.state.selectedInputName}</p>
      );

      componentDidMount() {

        fetch('https://dog.ceo/api/breeds/list/all')
        .then(res => res.json())
        .then((data) => {
          this.setState({ petlist: data['message'] })
          console.log(this.state.petlist)

          Object.entries(this.state.petlist).map(([key, val]) => 
            fetch(`https://dog.ceo/api/breed/${key}/images`)
            .then(res => res.json())
            .then((data) => {
              this.setState({ image: data['message'] })
              this.state.urllist.push(this.state.image[0])
              //console.log({this.state.urllist})
            })
            .catch(console.log)
        );
        })
        .catch(console.log)
      }

      render() {

        let doglist = this.state.petlist;
        let optionItems = Object.entries(doglist).map(([key, val]) => 
           <option key={key}>{key}</option>
        );

        return (
           <div className="container">
             <h1 className="title">PET SHOP</h1>

             <div className="filtercontainer">
               <p className="filter">Select a breed</p>
               <select onChange={this.handleChange}>
                {optionItems}
               </select>
               {this.makeTextInput()}
              <div className="row">
              {
                Object.entries(doglist).map(([key, val],j) => 
                 <div className="col-lg-4 col-xs-12 imagestyle" key={key}>
                   <p><CapitalizedText text={key}/></p>
                   <img width={250} height={250} src={this.state.urllist[j]}></img>
                 </div>
                )
              }
            </div>
            </div>
            </div>
        );

      }
}

render(
    <PetList/>,
    document.getElementById('root')
)

